package com.example.techmart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LenovoActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonbuy;
    private TextView textViewitems;
    private TextView textViewprice;
    private String CurrentUserID;

    private ElegantNumberButton Quantity;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    private int n5=1;
    private int n3;
    private int n4;
    private String id,name;
    private int price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lenovo);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Lenovo ideaPad s540");
        textViewitems=(TextView)findViewById(R.id.textViewitems);
        textViewprice=(TextView) findViewById(R.id.textViewprice);
        buttonbuy=(Button)findViewById(R.id.buttonbuy);
        Quantity=(ElegantNumberButton)findViewById(R.id.quantitybtn);
        buttonbuy.setOnClickListener(this);
        databaseReference= FirebaseDatabase.getInstance().getReference();
        firebaseAuth=FirebaseAuth.getInstance();
        CurrentUserID=firebaseAuth.getCurrentUser().getUid();
        getdata();
        Quantity.setOnValueChangeListener(new ElegantNumberButton.OnValueChangeListener() {
            @Override
            public void onValueChange(ElegantNumberButton view, int oldValue, int newValue) {
                String count =Quantity.getNumber();
                n5=Integer.valueOf(count);
            }
        });
    }
   private void getdata()
   {
       databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               if(dataSnapshot.hasChild("No of items Left"))
               {
                   String n = dataSnapshot.child("No of items Left").getValue().toString();
                   int m = Integer.valueOf(n);
                   String n1 = Integer.toString(m);
                   n3=m;
                   textViewitems.setText(n1);
               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });
       databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               if (dataSnapshot.hasChild("Price")) {
                   String n2 = dataSnapshot.child("Price").getValue().toString();
                   int m1 = Integer.valueOf(n2);
                   price=m1;
                   String n4 = Integer.toString(m1);
                   textViewprice.setText("₹"+n4);
               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });
       databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               if (dataSnapshot.hasChild("Product Name")) {
                   String n2 = dataSnapshot.child("Product Name").getValue().toString();
                   name=n2;
               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });
       databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               if(dataSnapshot.hasChild("ProductID"))
               {
                   String n = dataSnapshot.child("ProductID").getValue().toString();
                   int m = Integer.valueOf(n);
                   id=n;
               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });

   }
   private void putdata()
   {
       databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").child("No of items Left").setValue(n3);
       databaseReference.child("Users").child(CurrentUserID).child("Cart").child(id).child("Quantity").setValue(n4);
       databaseReference.child("Users").child(CurrentUserID).child("Cart").child(id).child("Price").setValue(price);
       databaseReference.child("Users").child(CurrentUserID).child("Cart").child(id).child("Name").setValue(name);
   }
    private void Buy() {
        databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("No of items Left"))
                {
                    String n = dataSnapshot.child("No of items Left").getValue().toString();
                    int m = Integer.valueOf(n);
                    String n1 = Integer.toString(m);
                    n3=m;
                    textViewitems.setText(n1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void Price() {
        databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("Price")) {
                    String n2 = dataSnapshot.child("Price").getValue().toString();
                    int m1 = Integer.valueOf(n2);
                    price=m1;
                    String n4 = Integer.toString(m1);
                    textViewprice.setText("₹"+n4);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void Name() {
        databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("Product Name")) {
                    String n2 = dataSnapshot.child("Product Name").getValue().toString();
                    name=n2;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void prodid() {
        databaseReference.child("Products").child("Laptops").child("Lenovo ideapad s540").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("ProductID"))
                {
                    String n = dataSnapshot.child("ProductID").getValue().toString();
                    int m = Integer.valueOf(n);
                    id=n;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if(v==buttonbuy) {
            if(n3>0) {
                n3 = n3 - n5;
                n4 = n4 + n5;
               putdata();
            }
            else
            {
                Toast.makeText(LenovoActivity.this,"No more Products Left",Toast.LENGTH_SHORT).show();
            }
        }

    }
}
