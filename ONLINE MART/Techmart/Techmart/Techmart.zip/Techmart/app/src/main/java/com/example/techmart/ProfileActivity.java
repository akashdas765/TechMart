package com.example.techmart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth firebaseAuth;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle toggle;
    public String currentUserID;
    public LinearLayout lenovo;
    public LinearLayout samsungtv;
    public LinearLayout oneplus7;
    public LinearLayout legion;
    public LinearLayout iphone1164;
    public LinearLayout canon;
    public LinearLayout note10;
    public LinearLayout iphone11pro;
    public LinearLayout oneplus7p;
    public LinearLayout s10;
    public LinearLayout iphone11;
    public LinearLayout oneplus7t;
    public LinearLayout lenovo1;
    public LinearLayout macair;
    public LinearLayout macpro;
    public LinearLayout legion1;
    public LinearLayout hpspec;
    public LinearLayout razer;
    public LinearLayout oneplustv;
    public LinearLayout samsungtv1;
    public LinearLayout lgtv;
    public LinearLayout sonyalpha;
    public LinearLayout nikon;
    public LinearLayout canon1;
    public LinearLayout sonym3;
    public LinearLayout airpods;
    public LinearLayout applewatch;
    public LinearLayout bosespeaker;
    public LinearLayout senheiser;
    public LinearLayout segate;
    private NavigationView navbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        mDrawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        toggle=new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        firebaseAuth = FirebaseAuth.getInstance();
        lenovo=(LinearLayout)findViewById(R.id.lenovo);
        samsungtv=(LinearLayout)findViewById(R.id.samsungtv);
        oneplus7=(LinearLayout)findViewById(R.id.oneplus7);
        legion=(LinearLayout)findViewById(R.id.legion);
        iphone1164=(LinearLayout)findViewById(R.id.iphone1164);
        canon=(LinearLayout)findViewById(R.id.canon);
        note10=(LinearLayout)findViewById(R.id.note10);
        iphone11pro=(LinearLayout)findViewById(R.id.iphone11pro);
        oneplus7p=(LinearLayout)findViewById(R.id.oneplus7p);
        s10=(LinearLayout)findViewById(R.id.s10);
        iphone11=(LinearLayout)findViewById(R.id.iphone11);
        oneplus7t=(LinearLayout)findViewById(R.id.oneplus7t);
        lenovo1=(LinearLayout)findViewById(R.id.lenovo1);
        macair=(LinearLayout)findViewById(R.id.macair);
        macpro=(LinearLayout)findViewById(R.id.macpro);
        legion1=(LinearLayout)findViewById(R.id.legion1);
        hpspec=(LinearLayout)findViewById(R.id.hpspec);
        razer=(LinearLayout)findViewById(R.id.razer);
        oneplustv=(LinearLayout)findViewById(R.id.oneplustv);
        samsungtv1=(LinearLayout)findViewById(R.id.samsungtv1);
        lgtv=(LinearLayout)findViewById(R.id.lgtv);
        sonyalpha=(LinearLayout)findViewById(R.id.sonyalpha);
        nikon=(LinearLayout)findViewById(R.id.nikon);
        canon1=(LinearLayout)findViewById(R.id.canon1);
        sonym3=(LinearLayout)findViewById(R.id.sonym3);
        airpods=(LinearLayout)findViewById(R.id.airpods);
        applewatch=(LinearLayout)findViewById(R.id.applewatch);
        bosespeaker=(LinearLayout)findViewById(R.id.bosespeaker);
        senheiser=(LinearLayout)findViewById(R.id.senheiser);
        segate=(LinearLayout)findViewById(R.id.segate);
        navbar=(NavigationView)findViewById(R.id.nav_bar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("TechMart");

        if (firebaseAuth.getCurrentUser() == null) {

            startActivity(new Intent(this, LoginActivity.class));
        }

        currentUserID = firebaseAuth.getCurrentUser().getUid();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        lenovo.setOnClickListener(this);
        samsungtv.setOnClickListener(this);
        oneplus7.setOnClickListener(this);
        legion.setOnClickListener(this);
        iphone1164.setOnClickListener(this);
        canon.setOnClickListener(this);
        note10.setOnClickListener(this);
        iphone11pro.setOnClickListener(this);
        oneplus7p.setOnClickListener(this);
        s10.setOnClickListener(this);
        iphone11.setOnClickListener(this);
        oneplus7t.setOnClickListener(this);
        lenovo1.setOnClickListener(this);
        macair.setOnClickListener(this);
        macpro.setOnClickListener(this);
        legion1.setOnClickListener(this);
        hpspec.setOnClickListener(this);
        razer.setOnClickListener(this);
        oneplustv.setOnClickListener(this);
        samsungtv1.setOnClickListener(this);
        lgtv.setOnClickListener(this);
        sonyalpha.setOnClickListener(this);
        nikon.setOnClickListener(this);
        canon1.setOnClickListener(this);
        sonym3.setOnClickListener(this);
        airpods.setOnClickListener(this);
        applewatch.setOnClickListener(this);
        bosespeaker.setOnClickListener(this);
        senheiser.setOnClickListener(this);
        segate.setOnClickListener(this);
        navbar.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                UserMenuSelector(menuItem);
                return false;
            }
        });
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, CartActivity.class));
            }
        });
    }
    private void UserMenuSelector(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.navlogout:
                firebaseAuth.signOut();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                break;
            case R.id.profile:
                startActivity(new Intent(this, MyprofileActivity.class));
                break;
            case R.id.cart:
                startActivity(new Intent(this, CartActivity.class));
                break;
        }
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(toggle.onOptionsItemSelected(item))
        {
            if(item.getItemId()==R.id.navlogout)
            {
                firebaseAuth.signOut();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        if(view==lenovo)
        {
          startActivity(new Intent(this,LenovoActivity.class));
        }
        if(view==samsungtv)
        {
            startActivity(new Intent(this,SamsungOLEDTVActivity.class));

        }
        if(view==oneplus7)
        {
            startActivity(new Intent(this,oneplus7Activity.class));

        }
        if(view==legion)
        {
            startActivity(new Intent(this,legionActivity.class));

        }
        if(view==iphone1164)
        {
            startActivity(new Intent(this,iphone11Activity.class));

        }
        if(view==canon)
        {
            startActivity(new Intent(this,CanonActivity.class));

        }
        if(view==note10)
        {
            startActivity(new Intent(this,SamsungnoteActivity.class));

        }
        if(view==iphone11pro)
        {
            startActivity(new Intent(this,iphone11proActivity.class));

        }
        if(view==oneplus7p)
        {
            startActivity(new Intent(this,oneplus7Activity.class));

        }
        if(view==s10)
        {
            startActivity(new Intent(this,samsungs10Activity.class));

        }
        if(view==iphone11)
        {
            startActivity(new Intent(this,iphone11Activity.class));

        }
        if(view==oneplus7t)
        {
            startActivity(new Intent(this,Oneplus7tActivity.class));

        }
        if(view==lenovo1)
        {
            startActivity(new Intent(this,LenovoActivity.class));

        }
        if(view==macair)
        {
            startActivity(new Intent(this,MacbookairActivity.class));

        }
        if(view==macpro)
        {
            startActivity(new Intent(this,MacbookproActivity.class));

        }
        if(view==legion1)
        {
            startActivity(new Intent(this,legionActivity.class));

        }
        if(view==hpspec)
        {
            startActivity(new Intent(this,HpspecActivity.class));

        }
        if(view==razer)
        {
            startActivity(new Intent(this,RazerActivity.class));

        }
        if(view==oneplustv)
        {
            startActivity(new Intent(this,OneplustvActivity.class));

        }
        if(view==samsungtv1)
        {
            startActivity(new Intent(this,SamsungOLEDTVActivity.class));

        }
        if(view==lgtv)
        {
            startActivity(new Intent(this,LGTVActivity.class));

        }
        if(view==sonyalpha)
        {
            startActivity(new Intent(this,SonyAlphaActivity.class));

        }
        if(view==nikon)
        {
            startActivity(new Intent(this,NikonActivity.class));

        }
        if(view==canon1)
        {
            startActivity(new Intent(this,CanonActivity.class));

        }
        if(view==sonym3)
        {
            startActivity(new Intent(this,SonyM3Activity.class));

        }
        if(view==airpods)
        {
            startActivity(new Intent(this,AirpodsActivity.class));

        }
        if(view==applewatch)
        {
            startActivity(new Intent(this,ApplewatchActivity.class));

        }
        if(view==bosespeaker)
        {
            startActivity(new Intent(this,BoseRevolveActivity.class));

        }
        if(view==senheiser)
        {
            startActivity(new Intent(this,SenheiserActivity.class));

        }
        if(view==segate)
        {
            startActivity(new Intent(this,SegateActivity.class));
        }

    }


}