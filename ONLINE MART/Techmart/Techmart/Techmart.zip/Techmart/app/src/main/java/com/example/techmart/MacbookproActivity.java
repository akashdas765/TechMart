package com.example.techmart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MacbookproActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonbuy;
    private TextView textViewitems;
    private TextView textViewprice;
    private String CurrentUserID;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private int n4;
    private int n3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_macbookpro);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Apple Macbook PRO 15-inch");
        textViewitems=(TextView)findViewById(R.id.textViewitems);
        textViewprice=(TextView) findViewById(R.id.textViewprice);
        buttonbuy=(Button)findViewById(R.id.buttonbuy);
        buttonbuy.setOnClickListener(this);
        firebaseAuth= FirebaseAuth.getInstance();
        CurrentUserID=firebaseAuth.getCurrentUser().getUid();
        databaseReference= FirebaseDatabase.getInstance().getReference();
        Buy();
        Price();
    }
    private void Buy() {
        databaseReference.child("Products").child("Laptops").child("Macbook Pro").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("No of items Left"))
                {
                    String n = dataSnapshot.child("No of items Left").getValue().toString();
                    int m = Integer.valueOf(n);
                    String n1 = Integer.toString(m);
                    n3=m;
                    textViewitems.setText(n1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void Price() {
        databaseReference.child("Products").child("Laptops").child("Macbook Pro").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("Price")) {
                    String n2 = dataSnapshot.child("Price").getValue().toString();
                    int m1 = Integer.valueOf(n2);
                    String n4 = Integer.toString(m1);
                    textViewprice.setText("₹"+n4);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public void onClick(View v) {
        if(v==buttonbuy) {
            if (n3 > 0) {
                n3 = n3 - 1;
                n4 = n4 + 1;
                databaseReference.child("Products").child("Laptops").child("Macbook Pro").child("No of items Left").setValue(n3);
                databaseReference.child("Users").child(CurrentUserID).child("Cart").child("Macbook Pro").child("No of items Sold").setValue(n4);
            } else {
                Toast.makeText(MacbookproActivity.this, "No more Products Left", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
