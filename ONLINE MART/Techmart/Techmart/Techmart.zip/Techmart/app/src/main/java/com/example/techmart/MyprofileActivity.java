package com.example.techmart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MyprofileActivity extends AppCompatActivity {
    private TextView name;
    private TextView email;
    private TextView gender;
    private TextView phone;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private String CurrentUserID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        name=(TextView)findViewById(R.id.name);
        gender=(TextView)findViewById(R.id.gender);
        email=(TextView)findViewById(R.id.email);
        phone=(TextView)findViewById(R.id.phone);
        firebaseAuth=FirebaseAuth.getInstance();
        user=firebaseAuth.getCurrentUser();
        email.setText(user.getEmail());
        databaseReference= FirebaseDatabase.getInstance().getReference();
        CurrentUserID=firebaseAuth.getCurrentUser().getUid();
        values();

    }
private void values()
{
    databaseReference.child("Users").child(CurrentUserID).addValueEventListener(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
       if(dataSnapshot.hasChild("Phone No"))
        {
            String S=dataSnapshot.child("Phone No").getValue().toString();
            phone.setText(S);
        }
        if(dataSnapshot.hasChild("Name"))
        {
            String N=dataSnapshot.child("Name").getValue().toString();
            name.setText(N);
        }
        if(dataSnapshot.hasChild("Gender"))
        {
            String N=dataSnapshot.child("Gender").getValue().toString();
            gender.setText(N);
        }
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
});
}
}
