package com.example.techmart;

public class Items{
    public String noitems;
    public Items()
    {
    }

    public Items(String noitems) {
        this.noitems = noitems;
    }
}